package com.es.eoi.shop.UI;

public abstract class ConsoleInterface {

}
