package com.es.eoi.shop.entities;

public class User {

	private String name;
	private String userName;
	private String password;
	private String[] address;
	private String mail;
	private String DNI;
	private Order[] orderHistory;
	
}
