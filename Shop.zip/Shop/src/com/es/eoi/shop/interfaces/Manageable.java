package com.es.eoi.shop.interfaces;

import com.es.eoi.shop.entities.Article;

public interface Manageable<T> {
		
	public void save(T obj);
	public void delete(T obj);
	

}
