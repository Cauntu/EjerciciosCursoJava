package com.es.eoi.shop.interfaces;

public interface Prizable {
	
	public Double getTotalPrice();

}
