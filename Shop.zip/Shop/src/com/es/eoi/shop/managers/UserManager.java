package com.es.eoi.shop.managers;

import java.io.FileNotFoundException;
import java.io.FileReader;

import com.es.eoi.shop.utils.TextUtils;
import com.es.eoi.shop.entities.User;


public class UserManager {

	public void registerUser(String mail, String userName, String password, String DNI) {

		java.io.File f = new java.io.File("");
		f = f.getParentFile();
		f = new java.io.File(f.getPath().concat("/datasources"));

		try {
			FileReader fr = new FileReader(f);
			searchMatchingKW(fr.read())
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
