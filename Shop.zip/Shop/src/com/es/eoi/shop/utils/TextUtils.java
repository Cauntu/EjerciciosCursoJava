package com.es.eoi.shop.utils;

public class TextUtils {
	
	//searches for keywords in a given text
	public String searchMatchingKW(String[] source, String kw) {
		
		String match;
		
		
		return match;
	}
	
}
